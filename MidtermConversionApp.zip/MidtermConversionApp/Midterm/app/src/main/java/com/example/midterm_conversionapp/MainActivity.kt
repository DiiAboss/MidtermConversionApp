import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import com.example.midterm_conversionapp.R

// MainActivity class that inherits from AppCompatActivity
class MainActivity : AppCompatActivity() {

    // onCreate function called when the activity is created
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find views in the layout
        val inputValue = findViewById<EditText>(R.id.inputValue)
        val conversionSpinner = findViewById<Spinner>(R.id.conversionSpinner)
        val convertButton = findViewById<Button>(R.id.convertButton)
        val outputValue = findViewById<TextView>(R.id.outputValue)

        // Create and set the adapter for the conversion spinner
        ArrayAdapter.createFromResource(
            this,
            R.array.conversion_types,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            conversionSpinner.adapter = adapter
        }

        // Set the click listener for the convert button
        convertButton.setOnClickListener {
            // Get the selected conversion type and input value string
            val selectedConversion = conversionSpinner.selectedItem.toString()
            val inputValueStr = inputValue.text.toString()

            // Check if the input value string is not empty
            if (inputValueStr.isNotEmpty()) {
                // Convert the input value string to a double
                val inputValueDouble = inputValueStr.toDouble()

                // Calculate the result based on the selected conversion type
                val result = when (selectedConversion) {
                    "Centimeters to Inches" -> inputValueDouble * 0.393701
                    "Inches to Centimeters" -> inputValueDouble * 2.54
                    "Meters to Feet" -> inputValueDouble * 3.28084
                    "Feet to Meters" -> inputValueDouble * 0.3048
                    "Celsius to Fahrenheit" -> (inputValueDouble * 9 / 5) + 32
                    "Fahrenheit to Celsius" -> (inputValueDouble - 32) * 5 / 9
                    "Kilometers to Miles" -> inputValueDouble * 0.621371
                    "Miles to Kilometers" -> inputValueDouble * 1.60934
                    else -> 0.0
                }

                // Set the output value text with the formatted result
                outputValue.text = String.format("%.2f", result)
            } else {
                // Clear the output value text if the input value string is empty
                outputValue.text = ""
            }
        }
    }
}



